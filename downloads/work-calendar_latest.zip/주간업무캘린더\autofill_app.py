# -*- coding: utf-8 -*-
"""
주간업무 캘린더 (WorkReport AutoFill v2)
────────────────────────────────────────────────────────────────
코드 기반 업무 일정 관리가 메인. 큰 주간 달력에서 직접 기록·수정하고,
주차별로 자동 저장된다. Outlook 불러오기/등록과 Excel 보고서는
툴바 버튼(팝오버)으로 제공.
실행:  streamlit run autofill_app.py   (또는 run.bat)
"""
import copy
import os
import json
import re
import pandas as pd
import streamlit as st
from datetime import date, datetime, timedelta
from pathlib import Path

from src.scheduler import (
    generate_week, copy_last_week, save_history, history_weights,
    day_segments, daily_hours, parse_hhmm,
    load_holidays, holiday_day_events, fill_gaps, _part_segments,
    load_week, list_history,
)
from src.validator import validate
from src.report_generator_web import generate_report_bytes
from src.outlook_writer import (
    outlook_available, register_events, CATEGORY,
    read_week_events, convert_outlook_rows,
)

try:
    from streamlit_calendar import calendar as st_calendar
except ImportError:
    st_calendar = None

APP_VERSION = "v2.5.3 (build 2026-07-13)"

BASE       = Path(__file__).parent
CONFIG_DIR = BASE / "config"
TEAMS_DIR  = CONFIG_DIR / "teams"
HIST_DIR   = CONFIG_DIR / "history"
OUTPUT_DIR = BASE / "output"
PREFS_PATH = CONFIG_DIR / "user_prefs.json"
ASSETS     = BASE / "assets"

DAY_KO = ["월", "화", "수", "목", "금", "토", "일"]

# 일정 자동 생성 기준 (팝오버에서 선택)
BASIS = {
    "임의 배치":             "random",
    "최근 1개월 이력 기반":   "history",
    "즐겨찾기 업무 중심":     "favorites",
    "전주 일정 복사":         "copy_last",
}

# Hexcore 브랜드 (00_Brand/DESIGN.md): 네이비 #22355F · 앰버 #E8A33D
NAVY, NAVY60, AMBER = "#22355F", "#4F5D7E", "#E8A33D"

_page_icon = ASSETS / "hexcore_32_v1.png"
st.set_page_config(page_title="주간업무 캘린더",
                   page_icon=str(_page_icon) if _page_icon.exists() else "⬡",
                   layout="wide", initial_sidebar_state="collapsed")

st.markdown(f"""<style>
@font-face {{
  font-family: 'Pretendard'; font-weight: 400;
  src: url('/app/static/fonts/Pretendard-Regular.woff2') format('woff2');
}}
@font-face {{
  font-family: 'Pretendard'; font-weight: 700;
  src: url('/app/static/fonts/Pretendard-Bold.woff2') format('woff2');
}}
html, body, [data-testid="stAppViewContainer"] * {{
  font-family: 'Pretendard', '맑은 고딕', 'Malgun Gothic', sans-serif;
}}
/* Material 아이콘은 아이콘 글꼴 유지 (전역 글꼴 덮어쓰기 예외) */
[data-testid="stIconMaterial"], .material-symbols-rounded,
[data-testid="stExpanderToggleIcon"] {{
  font-family: 'Material Symbols Rounded' !important;
}}
h1, h2, h3, [data-testid="stSidebar"] h1 {{ color: {NAVY} !important; }}
h1, h2, h3 {{ overflow: visible; }}
.block-container {{ padding-top: 2.8rem; padding-bottom: 1rem; }}
h3 {{ margin-top: 0; padding-top: 0.1rem; }}

/* 툴바를 촘촘하게 */
div[data-testid="stHorizontalBlock"] button {{ padding: 0.25rem 0.6rem; }}

div[data-testid="stAlert"] {{ border-radius: 4px; }}
div[data-testid="stAlert"]:has([data-testid="stAlertContentWarning"]) {{
  background: #FBF3E3; border-left: 3px solid {AMBER};
}}
div[data-testid="stAlert"]:has([data-testid="stAlertContentWarning"]) * {{ color: #6B4A0E; }}
div[data-testid="stAlert"]:has([data-testid="stAlertContentInfo"]) {{
  background: #E9EDF5; border-left: 3px solid {NAVY};
}}
div[data-testid="stAlert"]:has([data-testid="stAlertContentInfo"]) * {{ color: {NAVY}; }}
div[data-testid="stAlert"]:has([data-testid="stAlertContentSuccess"]) {{
  background: #E9EDF5; border-left: 3px solid {NAVY};
}}
div[data-testid="stAlert"]:has([data-testid="stAlertContentSuccess"]) * {{ color: {NAVY}; }}
div[data-testid="stAlert"]:has([data-testid="stAlertContentError"]) {{
  background: #F9ECEA; border-left: 3px solid #C0392B;
}}
div[data-testid="stAlert"]:has([data-testid="stAlertContentError"]) * {{ color: #7B241C; }}

[data-testid="stSidebar"] {{ background: #F2F2F2; }}
[data-testid="stSidebar"] hr {{ border-color: #D9D9D9; }}
</style>""", unsafe_allow_html=True)

CAL_CSS = """
.fc { font-family: 'Pretendard','맑은 고딕',sans-serif; font-size: .8rem; }
.fc .fc-toolbar-title { color:#22355F; font-size:1rem; font-weight:700; }
.fc .fc-col-header-cell-cushion { color:#22355F; font-weight:700; }
.fc-event { border-radius:3px; font-size:.72rem; line-height:1.15; cursor:pointer; }
.fc .fc-timegrid-slot { height: 1.55em; }
.fc .fc-daygrid-day-number { color:#22355F; }
/* 오늘 강조: 기본 노랑 → 브랜드 네이비 틴트 */
.fc .fc-day-today { background: #EFF3FA !important; }
/* 종일 줄 근무/휴무 칩: 가운데 정렬 */
.fc .fc-daygrid-event { text-align:center; }
.fc .fc-daygrid-event .fc-event-title {
  width:100%; text-align:center; font-weight:600; float:none;
}
/* 블록 위/아래 리사이즈 핸들: 잡기 쉽게 + 마우스 올리면 표시 */
.fc-v-event .fc-event-resizer { display:block; height:10px; }
.fc-v-event:hover .fc-event-resizer-start,
.fc-v-event:hover .fc-event-resizer-end {
  background: rgba(255,255,255,.45); cursor: ns-resize;
}
"""


# ── 설정 로드/저장 ────────────────────────────────────────────────────
@st.cache_data
def load_teams() -> list[tuple[str, dict]]:
    teams = []
    for p in sorted(TEAMS_DIR.glob("*.json")):
        if p.stem.startswith("_"):
            continue
        try:
            teams.append((p.stem, json.loads(p.read_text(encoding="utf-8"))))
        except Exception:
            pass
    return teams


def load_prefs() -> dict:
    try:
        return json.loads(PREFS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_prefs(prefs: dict):
    PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
    PREFS_PATH.write_text(json.dumps(prefs, ensure_ascii=False, indent=1),
                          encoding="utf-8")


def code_label(c: dict) -> str:
    return f"[{c.get('type','?')}] {c.get('level1_name','')} · {c.get('name','')} ({c.get('code','')})"


def _seed_widget(key: str, value):
    if key not in st.session_state:
        st.session_state[key] = value


def _monday_of(d: date) -> date:
    return d - timedelta(days=d.weekday())


def _parse_cal_dt(s) -> datetime:
    dt = datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    if dt.tzinfo is not None:
        dt = dt.astimezone()      # UTC 표시 → 로컬(KST)로 변환 후 tz 제거
    return dt.replace(tzinfo=None, second=0, microsecond=0)


# ── 표 편집 보조 ──────────────────────────────────────────────────────
def _to_df(events: list) -> pd.DataFrame:
    rows = []
    for ev in events:
        d = ev["date"]
        rows.append({
            "포함": ev.get("included", True),
            "날짜": d.strftime("%m/%d"),
            "요일": DAY_KO[d.weekday()],
            "시작": ev["start"].strftime("%H:%M"),
            "종료": ev["end"].strftime("%H:%M"),
            "M/H":  ev["duration_hours"],
            "업무": ev.get("_label", ""),
            "제목": ev.get("title", ""),
            "유형": ev.get("code_type", "미분류"),
        })
    return pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=["포함", "날짜", "요일", "시작", "종료", "M/H", "업무", "제목", "유형"])


def resolve_overlaps(events: list, idx: int) -> list:
    """idx 이벤트가 이동/리사이즈로 이웃과 겹치면 이웃을 줄이거나 제거.
    (늘리면 아래 블록이 밀려 줄어드는 직관적 동작)"""
    e = events[idx]
    out = []
    for i, ev in enumerate(events):
        if i == idx or not ev.get("included", True) \
                or ev["date"] != e["date"]:
            out.append(ev)
            continue
        if not (ev["start"] < e["end"] and ev["end"] > e["start"]):
            out.append(ev)                     # 겹침 없음
            continue
        nv = dict(ev)
        if ev["start"] >= e["start"] and ev["end"] <= e["end"]:
            continue                            # 완전히 덮임 → 제거
        if ev["start"] < e["start"] and ev["end"] > e["end"]:
            nv["end"] = e["start"]              # e가 가운데 → 앞부분만 유지
        elif ev["start"] < e["start"]:
            nv["end"] = e["start"]              # 꼬리가 겹침 → 끝을 당김
        else:
            nv["start"] = e["end"]              # 머리가 겹침 → 시작을 밀음
        dur = (nv["end"] - nv["start"]).total_seconds() / 3600
        if dur < 0.5 - 1e-9:                    # 30분 미만으로 쪼그라들면 제거
            continue
        nv["duration_hours"] = round(dur, 2)
        out.append(nv)
    return out


def _apply_edits(events: list, edited: pd.DataFrame, by_label: dict) -> list:
    out = []
    for i, ev in enumerate(events):
        if i >= len(edited):
            out.append(ev)
            continue
        row = edited.iloc[i]
        e = dict(ev)
        e["included"] = bool(row["포함"])
        c = by_label.get(str(row["업무"]))
        if c and c["code"] != e.get("code"):
            if e.get("title", "") == e.get("work_name", ""):
                e["title"] = c["name"]
            e["work_name"] = c["name"]
            e["code"]      = c["code"]
            e["code_type"] = c.get("type", "미분류")
            e["_label"]    = code_label(c)
        t = str(row["제목"]).strip()
        if t:
            e["title"] = t
        out.append(e)
    return out


# ── 메인 ──────────────────────────────────────────────────────────────
def main():
    for k, v in {"weeks": {}, "cal_mode": "week", "cal_nonce": 0,
                 "cur_mon": _monday_of(date.today()),
                 "prefs": load_prefs()}.items():
        if k not in st.session_state:
            st.session_state[k] = v

    teams = load_teams()
    if not teams:
        st.error("config/teams 에 팀 코드 JSON이 없습니다.")
        st.stop()
    prefs = st.session_state.prefs

    # ── 사이드바 (설정 — 기본 접힘) ─────────────────────────────────
    with st.sidebar:
        st.title("설정")
        team_names = [cfg.get("team_name", tid) for tid, cfg in teams]
        # 기본 팀 = Xe-100 CI PJT, 이후에는 마지막 선택을 기억
        _def_team = prefs.get("last_team", "Xe-100 CI PJT")
        _seed_widget("team_sel",
                     _def_team if _def_team in team_names else team_names[0])
        if st.session_state.get("team_sel") not in team_names:
            st.session_state["team_sel"] = team_names[0]
        sel = st.selectbox("팀(부서) 선택", team_names, key="team_sel")
        team_id, team_cfg = teams[team_names.index(sel)]
        codes = team_cfg.get("codes", [])
        by_label = {code_label(c): c for c in codes}
        labels   = list(by_label.keys())
        by_code  = {c["code"]: c for c in codes}
        tp = (st.session_state.prefs.setdefault("teams", {})
              .setdefault(team_id, {}))

        user_name = st.text_input("성명", value=prefs.get("user_name", ""))
        emp_id    = st.text_input("사번", value=prefs.get("employee_id", ""))

        st.divider()
        st.subheader("근무시간 (부서별)")
        _seed_widget(f"{team_id}_ws", parse_hhmm(tp.get("work_start",  "08:30")))
        _seed_widget(f"{team_id}_ls", parse_hhmm(tp.get("lunch_start", "12:00")))
        _seed_widget(f"{team_id}_le", parse_hhmm(tp.get("lunch_end",   "13:00")))
        _seed_widget(f"{team_id}_we", parse_hhmm(tp.get("work_end",    "17:30")))
        c1, c2 = st.columns(2)
        with c1:
            t_ws = st.time_input("출근",     key=f"{team_id}_ws", step=1800)
            t_ls = st.time_input("점심 시작", key=f"{team_id}_ls", step=1800)
        with c2:
            t_we = st.time_input("퇴근",     key=f"{team_id}_we", step=1800)
            t_le = st.time_input("점심 종료", key=f"{team_id}_le", step=1800)
        d_hours = daily_hours(day_segments(t_ws, t_we, t_ls, t_le))
        target  = d_hours * 5
        st.caption(f"일 {d_hours:.1f}h × 5일 = 주 {target:.1f}h")

        st.divider()
        st.subheader("자동 생성 옵션")
        _seed_widget(f"{team_id}_min", tp.get("min_block", 1.0))
        _seed_widget(f"{team_id}_max", tp.get("max_block", 4.0))
        _max_opts = [2.0, 3.0, 4.0, 4.5]
        if st.session_state[f"{team_id}_max"] not in _max_opts:
            st.session_state[f"{team_id}_max"] = 4.5
        c3, c4 = st.columns(2)
        with c3:
            min_h = st.selectbox("업무 최소 시간(h)",
                                 [0.5, 1.0, 1.5, 2.0, 3.0, 4.0],
                                 key=f"{team_id}_min")
        with c4:
            max_h = st.selectbox("업무 최대 시간(h)", _max_opts,
                                 key=f"{team_id}_max")
        if max_h < min_h:
            max_h = min_h

        st.divider()
        st.subheader("★ 즐겨찾기 업무")
        saved_fav = [c for c in tp.get("favorites", []) if c in by_code]
        _seed_widget(f"{team_id}_fav",
                     [code_label(by_code[c]) for c in saved_fav])
        fav_labels = st.multiselect("'즐겨찾기만 배치'에서 사용",
                                    labels, key=f"{team_id}_fav")
        favorites = [by_label[l]["code"] for l in fav_labels]

        st.divider()
        st.subheader("휴무 처리 코드")
        _auto_hol = next((code_label(c) for c in codes
                          if re.search(r"휴가|휴무|휴일|연차", c.get("name", ""))),
                         labels[0])
        hol_key = f"{team_id}_holcode"
        saved_hol = tp.get("holiday_code")
        _seed_widget(hol_key, code_label(by_code[saved_hol])
                     if saved_hol in by_code else _auto_hol)
        if st.session_state.get(hol_key) not in labels:
            st.session_state[hol_key] = _auto_hol
        hol_label = st.selectbox("휴무일에 하루 전체로 배치될 코드",
                                 labels, key=hol_key)
        holiday_task = by_label[hol_label]

        st.divider()
        st.subheader("정기 일정 (매주 반복)")
        st.caption("주간회의처럼 매주 반복되는 일정 — 새 주를 열 때 "
                   "자동으로 배치되고, 자동 생성 시에도 유지됩니다.")
        _times = [f"{h:02d}:{m:02d}" for h in range(7, 20) for m in (0, 30)]
        _rec_saved = tp.get("recurring", [])
        rec_df = pd.DataFrame(_rec_saved) if _rec_saved else pd.DataFrame(
            columns=["day", "start", "end", "label", "title"])
        rec_edit = st.data_editor(
            rec_df, num_rows="dynamic", hide_index=True,
            use_container_width=True,
            key=f"{team_id}_rec_editor",
            column_config={
                "day":   st.column_config.SelectboxColumn(
                    "요일", options=DAY_KO[:5], width=60, required=True),
                "start": st.column_config.SelectboxColumn(
                    "시작", options=_times, width=75, required=True),
                "end":   st.column_config.SelectboxColumn(
                    "종료", options=_times, width=75, required=True),
                "label": st.column_config.SelectboxColumn(
                    "업무", options=labels, width=220, required=True),
                "title": st.column_config.TextColumn("제목(선택)", width=140),
            })
        _rec_rows = []
        for _, r in rec_edit.iterrows():
            if (r.get("day") in DAY_KO[:5] and r.get("start") in _times
                    and r.get("end") in _times and r.get("label") in by_label
                    and str(r["start"]) < str(r["end"])):
                _rec_rows.append({"day": r["day"], "start": r["start"],
                                  "end": r["end"], "label": r["label"],
                                  "title": str(r.get("title") or "").strip()})
        tp["recurring"] = _rec_rows
        if st.button("보고 있는 주에 지금 적용", use_container_width=True,
                     disabled=not _rec_rows,
                     help="이미 열려 있는 주에는 자동 배치되지 않으므로, "
                          "이 버튼으로 빈 시간에 한해 추가합니다"):
            st.session_state["apply_recurring"] = True

        st.divider()
        st.caption(f"⬡ Hexcore · {APP_VERSION.split()[0]} · 2026-07-10")

    prefs["user_name"]   = user_name
    prefs["employee_id"] = emp_id
    prefs["last_team"]   = sel
    tp.update({
        "work_start": t_ws.strftime("%H:%M"), "work_end": t_we.strftime("%H:%M"),
        "lunch_start": t_ls.strftime("%H:%M"), "lunch_end": t_le.strftime("%H:%M"),
        "min_block": min_h, "max_block": max_h,
        "favorites": favorites, "holiday_code": holiday_task["code"],
    })
    save_prefs(prefs)

    # ── 주차 데이터 계층 (자동 저장/로드) ───────────────────────────
    cur: date = st.session_state.cur_mon
    hols = load_holidays(CONFIG_DIR, {cur.year - 1, cur.year, cur.year + 1})

    def _wk_kwargs() -> dict:
        return dict(work_start=t_ws.strftime("%H:%M"),
                    work_end=t_we.strftime("%H:%M"),
                    lunch_start=t_ls.strftime("%H:%M"),
                    lunch_end=t_le.strftime("%H:%M"))

    def _attach_labels(events: list) -> list:
        for ev in events:
            c = by_code.get(ev.get("code"))
            ev["_label"] = code_label(c) if c else \
                f"[{ev.get('code_type','?')}] {ev.get('work_name','')} ({ev.get('code','')})"
        return events

    def _wkey(monday: date) -> str:
        return f"{team_id}_{monday.isoformat()}"

    def _recurring_events(monday: date, skip_days: set) -> list:
        """정기 일정 템플릿 → 해당 주의 이벤트 목록 (휴무일 제외)."""
        out = []
        for r in tp.get("recurring", []):
            try:
                wd = DAY_KO.index(r["day"])
            except (ValueError, KeyError):
                continue
            d = monday + timedelta(days=wd)
            if d in skip_days:
                continue
            c = by_label.get(r.get("label"))
            if not c:
                continue
            s_dt = datetime.combine(d, parse_hhmm(r["start"]))
            e_dt = datetime.combine(d, parse_hhmm(r["end"]))
            if e_dt <= s_dt:
                continue
            out.append({
                "date": d, "start": s_dt, "end": e_dt,
                "duration_hours": round(
                    (e_dt - s_dt).total_seconds() / 3600, 2),
                "title": r.get("title") or c["name"],
                "work_name": c["name"], "code": c["code"],
                "code_type": c.get("type", "미분류"),
                "included": True, "recurring": True,
            })
        return out

    def _week(monday: date) -> list:
        """주차 데이터: 세션 캐시 → 저장 파일 → 신규(공휴일 휴무+정기 일정)."""
        k = _wkey(monday)
        if k not in st.session_state.weeks:
            ev = load_week(HIST_DIR, team_id, monday)
            if ev is None:
                ev = []
                hol_days = set()
                for wd in range(5):
                    d = monday + timedelta(days=wd)
                    if d in hols:
                        hol_days.add(d)
                        ev.extend(holiday_day_events(
                            d, holiday_task, hols[d], "full", **_wk_kwargs()))
                ev.extend(_recurring_events(monday, hol_days))
                ev.sort(key=lambda e: e["start"])
            st.session_state.weeks[k] = _attach_labels(ev)
        return st.session_state.weeks[k]

    def _set_week(monday: date, events: list, save: bool = True):
        events.sort(key=lambda e: e["start"])
        st.session_state.weeks[_wkey(monday)] = _attach_labels(events)
        if save:
            save_history(HIST_DIR, team_id, monday, events)

    def _mutate(monday: date, rerun: bool = True):
        _set_week(monday, _week(monday))
        st.session_state.cal_nonce += 1
        if rerun:
            st.rerun()

    # ── 되돌리기 (주차별 최근 20단계) ───────────────────────────────
    def _push_undo(monday: date):
        """변경 직전 상태를 스냅샷 — 모든 편집·생성·가져오기 전에 호출."""
        stack = (st.session_state.setdefault("undo", {})
                 .setdefault(_wkey(monday), []))
        stack.append(copy.deepcopy(_week(monday)))
        if len(stack) > 20:
            stack.pop(0)

    def _undo_stack(monday: date) -> list:
        return st.session_state.get("undo", {}).get(_wkey(monday), [])

    def _undo(monday: date):
        stack = _undo_stack(monday)
        if not stack:
            st.toast("되돌릴 작업이 없습니다.")
            return
        _set_week(monday, stack.pop())
        st.session_state.cal_nonce += 1
        st.toast("한 단계 되돌렸습니다.")
        st.rerun()

    def _day_is_hol(events: list, d: date) -> bool:
        return any(e["date"] == d and e.get("is_holiday")
                   and e.get("holiday_part", "full") == "full"
                   and e.get("included", True) for e in events)

    def _toggle_day(monday: date, d: date):
        _push_undo(monday)
        ev = _week(monday)
        if _day_is_hol(ev, d):
            ev = [e for e in ev if not (e["date"] == d and e.get("is_holiday"))]
        else:
            ev = [e for e in ev if e["date"] != d]
            ev.extend(holiday_day_events(d, holiday_task, hols.get(d, ""),
                                         "full", **_wk_kwargs()))
        _set_week(monday, ev)
        st.session_state.cal_nonce += 1
        st.rerun()

    # ── 자동 채우기 / 생성 ──────────────────────────────────────────
    def _week_hols(monday: date) -> dict:
        ev = _week(monday)
        out = {}
        for wd in range(5):
            d = monday + timedelta(days=wd)
            if _day_is_hol(ev, d):
                out[d] = (hols.get(d, "연차"), "full")
        return out

    def _generate(monday: date, gen_mode: str):
        week_hols = _week_hols(monday)
        try:
            if gen_mode == "copy_last":
                ev = copy_last_week(HIST_DIR, team_id, monday)
                if ev is None:
                    st.error("복사할 과거 주 이력이 없습니다.")
                    return
                if week_hols:
                    segs_full = day_segments(t_ws, t_we, t_ls, t_le)
                    kept = []
                    for e in ev:
                        hv = week_hols.get(e["date"])
                        if hv:
                            hol_segs, _ = _part_segments(segs_full, hv[1])
                            if any(e["start"].time() < b and e["end"].time() > a
                                   for a, b in hol_segs):
                                continue
                        kept.append(e)
                    ev = kept
                    for d, (name, part) in week_hols.items():
                        ev.extend(holiday_day_events(d, holiday_task, name,
                                                     part, **_wk_kwargs()))
            else:
                hw = (history_weights(HIST_DIR, team_id, recent_n=4,
                                      before=monday)
                      if gen_mode == "history" else {})
                if gen_mode == "favorites" and not favorites:
                    st.error("즐겨찾기가 비어 있습니다. 설정에서 등록하세요.")
                    return
                # 뼈대(휴무 + 정기 일정)는 유지하고 나머지 시간만 새로 배치
                cur_ev = _week(monday)
                skeleton = []
                for d, (name, part) in week_hols.items():
                    skeleton.extend(holiday_day_events(
                        d, holiday_task, name, part, **_wk_kwargs()))
                skeleton.extend(
                    copy.deepcopy(e) for e in cur_ev
                    if e.get("recurring") and e.get("included", True)
                    and e["date"] not in week_hols)
                added = fill_gaps(skeleton, monday, codes, mode=gen_mode,
                                  favorites=favorites, history_weights=hw,
                                  min_h=min_h, max_h=max_h, **_wk_kwargs())
                ev = skeleton + added
            _push_undo(monday)
            _set_week(monday, ev)
            st.session_state.cal_nonce += 1
            st.toast(f"{len(ev)}건 배치 완료")
            st.rerun()
        except Exception as e:
            st.error(f"생성 오류: {e}")

    def _fill(monday: date, gen_mode: str):
        try:
            f_mode = "random" if gen_mode == "copy_last" else gen_mode
            if f_mode == "favorites" and not favorites:
                st.error("즐겨찾기가 비어 있습니다.")
                return
            hw = (history_weights(HIST_DIR, team_id, recent_n=4,
                                  before=monday)
                  if f_mode == "history" else {})
            added = fill_gaps(_week(monday), monday, codes,
                              mode=f_mode, favorites=favorites,
                              history_weights=hw, min_h=min_h, max_h=max_h,
                              **_wk_kwargs())
            if added:
                _push_undo(monday)
                ev = _week(monday) + added
                _set_week(monday, ev)
                st.session_state.cal_nonce += 1
                st.toast(f"{len(added)}건 채움")
                st.rerun()
            else:
                st.toast("채울 빈 시간이 없습니다.")
        except Exception as e:
            st.error(f"채우기 오류: {e}")

    # ── 다이얼로그 ──────────────────────────────────────────────────
    @st.dialog("업무 블록 편집")
    def _edit_dialog(monday: date, idx: int):
        events = _week(monday)
        e = events[idx]
        if e.get("from_outlook"):
            st.caption("Outlook에서 불러온 일정 — 수정해도 보고서에만 반영되고 "
                       "Outlook 원본은 바뀌지 않습니다.")
        cur_lab = e.get("_label", "")
        KEEP = "— 미분류로 유지 —"
        opts = ([KEEP] + labels) if e.get("code") == "미분류" else labels
        lab = st.selectbox("업무 코드", opts,
                           index=opts.index(cur_lab) if cur_lab in opts else 0)
        c1, c2 = st.columns(2)
        s_t = c1.time_input("시작", value=e["start"].time(), step=900)
        e_t = c2.time_input("종료", value=e["end"].time(), step=900)
        ttl = st.text_input("제목 (보고서 표기)", value=e.get("title", ""))
        b1, b2 = st.columns(2)
        if b1.button("저장", type="primary", use_container_width=True):
            if e_t <= s_t:
                st.error("종료 시간이 시작 시간보다 빨라야 합니다.")
            else:
                nd = dict(e)
                if lab != KEEP:                # 미분류 유지면 코드 변경 없음
                    c = by_label[lab]
                    if c["code"] != e.get("code"):
                        nd["is_holiday"] = False
                        nd.pop("holiday_part", None)
                    nd.update(work_name=c["name"], code=c["code"],
                              code_type=c.get("type", "미분류"), _label=lab)
                    nd["title"] = ttl.strip() or c["name"]
                else:
                    nd["title"] = ttl.strip() or e.get("title", "")
                nd["start"] = datetime.combine(e["date"], s_t)
                nd["end"] = datetime.combine(e["date"], e_t)
                nd["duration_hours"] = round(
                    (nd["end"] - nd["start"]).total_seconds() / 3600, 2)
                _push_undo(monday)
                events[idx] = nd
                st.session_state.weeks[_wkey(monday)] = \
                    resolve_overlaps(events, idx)
                _mutate(monday)
        if b2.button("삭제", use_container_width=True):
            _push_undo(monday)
            events.pop(idx)
            _mutate(monday)

    @st.dialog("업무 블록 추가")
    def _add_dialog(monday: date, d: date, s0: datetime, e0: datetime):
        st.caption(f"{d:%m/%d}({DAY_KO[d.weekday()]})")
        lab = st.selectbox("업무 코드", labels)
        c1, c2 = st.columns(2)
        s_t = c1.time_input("시작", value=s0.time(), step=900)
        e_t = c2.time_input("종료", value=e0.time(), step=900)
        if st.button("추가", type="primary", use_container_width=True):
            if e_t <= s_t:
                st.error("종료 시간이 시작 시간보다 빨라야 합니다.")
            else:
                c = by_label[lab]
                s_dt, e_dt = datetime.combine(d, s_t), datetime.combine(d, e_t)
                _push_undo(monday)
                _week(monday).append({
                    "date": d, "start": s_dt, "end": e_dt,
                    "duration_hours": round(
                        (e_dt - s_dt).total_seconds() / 3600, 2),
                    "title": c["name"], "work_name": c["name"],
                    "code": c["code"], "code_type": c.get("type", "미분류"),
                    "included": True, "_label": code_label(c),
                })
                ev_all = _week(monday)
                st.session_state.weeks[_wkey(monday)] = \
                    resolve_overlaps(ev_all, len(ev_all) - 1)
                _mutate(monday)

    # ── Outlook ─────────────────────────────────────────────────────
    if "outlook_status" not in st.session_state:
        st.session_state.outlook_status = outlook_available()
    ol_ok, ol_msg = st.session_state.outlook_status

    def _import_week(monday: date, scope_all: bool):
        try:
            with st.spinner("Outlook에서 일정을 읽는 중..."):
                rows = read_week_events(monday)
            imported, n_auto = convert_outlook_rows(rows, monday, codes,
                                                    scope_all)
            _push_undo(monday)
            kept = [e for e in _week(monday) if not e.get("from_outlook")]
            _set_week(monday, kept + imported)
            st.session_state.cal_nonce += 1
            miscls = sum(1 for e in imported if e["code"] == "미분류")
            msg = f"{len(imported)}건 불러옴"
            if miscls:
                msg += f" (미분류 {miscls}건 — 클릭해 코드 지정)"
            st.toast(msg)
            st.rerun()
        except Exception as e:
            st.error(f"불러오기 오류: {e}")

    def _register_week(monday: date, replace: bool):
        events = _week(monday)
        evs = [e for e in events if e.get("included", True)
               and not e.get("from_outlook")]
        n_imp = sum(1 for e in events
                    if e.get("included", True) and e.get("from_outlook"))
        if not evs:
            st.error("등록할 업무가 없습니다.")
            return
        try:
            with st.spinner("Outlook에 등록 중..."):
                n, d = register_events(evs, monday, replace=replace)
            _set_week(monday, events)
            st.success(f"{n}건 등록 완료"
                       + (f" · 기존 자동등록 {d}건 교체" if d else "")
                       + (f" · Outlook 원본 {n_imp}건 유지" if n_imp else ""))
        except Exception as e:
            st.error(f"Outlook 등록 오류: {e}")

    # ── 정기 일정 '지금 적용' 처리 ──────────────────────────────────
    if st.session_state.pop("apply_recurring", False):
        _m0 = st.session_state.cur_mon
        ev0 = _week(_m0)
        skip = {_m0 + timedelta(days=w) for w in range(5)
                if _day_is_hol(ev0, _m0 + timedelta(days=w))}
        cand = _recurring_events(_m0, skip)
        added = [c for c in cand
                 if not any(e.get("included", True) and e["date"] == c["date"]
                            and e["start"] < c["end"] and e["end"] > c["start"]
                            for e in ev0)]
        if added:
            _push_undo(_m0)
            _set_week(_m0, ev0 + added)
            st.session_state.cal_nonce += 1
            st.toast(f"정기 일정 {len(added)}건 적용")
        else:
            st.toast("겹치지 않는 빈 시간이 없어 추가할 항목이 없습니다.")

    # ── 뷰 상태 (일/주/월/분석) ─────────────────────────────────────
    VIEW_MAP = {"일": "day", "주": "week", "월": "month"}
    _seed_widget("view_seg", "주")
    _seed_widget("stats_on", False)
    _seed_widget("cur_day", date.today() if date.today().weekday() < 5
                 else _monday_of(date.today()))
    _pend = st.session_state.pop("view_pending", None)
    if _pend in VIEW_MAP:
        st.session_state["view_seg"] = _pend
    _view = st.session_state.get("view_seg") or "주"
    eff = "stats" if st.session_state.stats_on else VIEW_MAP.get(_view, "week")
    if eff == "day" and _monday_of(st.session_state.cur_day) != cur:
        st.session_state.cur_day = cur
    day: date = st.session_state.cur_day
    month_mode = eff == "month"
    no_edit = eff in ("month", "stats")
    events = _week(cur)
    fri = cur + timedelta(days=4)

    def _biz_shift(d: date, step: int) -> date:
        d = d + timedelta(days=step)
        while d.weekday() >= 5:
            d = d + timedelta(days=step)
        return d

    # ── 헤더 + 툴바 ─────────────────────────────────────────────────
    import base64 as _b64
    _logo = ASSETS / "hexcore_32_v1.png"
    _logo_html = ""
    if _logo.exists():
        _logo_html = ("<img src='data:image/png;base64,"
                      + _b64.b64encode(_logo.read_bytes()).decode()
                      + "' width='26' height='26'>")
    st.markdown(
        f"<div style='display:flex;align-items:center;gap:10px;"
        f"margin-bottom:0.4rem'>{_logo_html}"
        f"<span style='font-size:1.35rem;font-weight:700;color:{NAVY}'>"
        f"주간업무 캘린더</span>"
        f"<span style='color:{NAVY60};font-size:0.78rem;"
        f"padding-top:6px'>{team_cfg.get('team_name','')}</span></div>",
        unsafe_allow_html=True)

    tb = st.columns([0.42, 0.5, 0.42, 1.9, 1.2, 0.95, 1.5, 1.5, 1.1, 0.95, 0.8])
    with tb[0]:
        if st.button("◀", use_container_width=True, disabled=eff == "stats"):
            if eff == "day":
                nd = _biz_shift(day, -1)
                st.session_state.cur_day = nd
                st.session_state.cur_mon = _monday_of(nd)
            elif month_mode:
                d1 = (cur.replace(day=1) - timedelta(days=1)).replace(day=1)
                st.session_state.cur_mon = _monday_of(d1)
            else:
                st.session_state.cur_mon = cur - timedelta(weeks=1)
                st.session_state.cur_day = st.session_state.cur_mon
            st.rerun()
    with tb[1]:
        if st.button("오늘", use_container_width=True, disabled=eff == "stats"):
            td = date.today()
            if td.weekday() >= 5:
                td = _monday_of(td) + timedelta(weeks=1)
            st.session_state.cur_day = td
            st.session_state.cur_mon = _monday_of(td)
            st.rerun()
    with tb[2]:
        if st.button("▶", use_container_width=True, disabled=eff == "stats"):
            if eff == "day":
                nd = _biz_shift(day, 1)
                st.session_state.cur_day = nd
                st.session_state.cur_mon = _monday_of(nd)
            elif month_mode:
                d1 = (cur.replace(day=28) + timedelta(days=7)).replace(day=1)
                st.session_state.cur_mon = _monday_of(d1)
            else:
                st.session_state.cur_mon = cur + timedelta(weeks=1)
                st.session_state.cur_day = st.session_state.cur_mon
            st.rerun()
    with tb[3]:
        if eff == "stats":
            label = "업무 분석"
        elif eff == "day":
            label = f"{day:%Y.%m.%d} ({DAY_KO[day.weekday()]})"
            if day == date.today():
                label += " · 오늘"
        elif month_mode:
            label = f"{cur.year}년 {cur.month}월"
        else:
            label = f"{cur:%Y.%m.%d}(월) ~ {fri:%m.%d}(금)"
            if cur == _monday_of(date.today()):
                label += " · 이번 주"
        st.markdown(f"<div style='text-align:center;color:{NAVY};"
                    f"font-weight:700;padding-top:0.35rem;"
                    f"white-space:nowrap'>{label}</div>",
                    unsafe_allow_html=True)
    with tb[4]:
        st.segmented_control("보기", ["일", "주", "월"], key="view_seg",
                             label_visibility="collapsed")
    with tb[5]:
        if st.button("↩ 되돌리기", use_container_width=True,
                     disabled=no_edit or not _undo_stack(cur),
                     help="가장 최근 변경(입력·수정·삭제·생성 등)을 한 단계 취소"):
            _undo(cur)
    with tb[6]:
        with st.popover("일정 자동 생성 ▾", use_container_width=True,
                        disabled=no_edit):
            _seed_widget(f"{team_id}_basis", tp.get("gen_basis", "임의 배치"))
            if st.session_state[f"{team_id}_basis"] not in BASIS:
                st.session_state[f"{team_id}_basis"] = "임의 배치"
            basis = st.radio("생성 기준", list(BASIS.keys()),
                             key=f"{team_id}_basis")
            gen_mode = BASIS[basis]
            if gen_mode == "copy_last":
                scope = "주 전체 재생성"
                st.caption("전주 복사는 주 전체를 대상으로 합니다.")
            else:
                scope = st.radio("생성 범위",
                                 ["잔여 시간만 (기존 일정 유지)",
                                  "주 전체 재생성"],
                                 key="gen_scope")
                st.caption("주 전체 재생성 시에도 휴무·정기 일정은 유지됩니다.")
            tp["gen_basis"] = basis
            save_prefs(prefs)
            if st.button("일정 생성", type="primary",
                         use_container_width=True):
                if scope.startswith("잔여"):
                    _fill(cur, gen_mode)
                else:
                    _generate(cur, gen_mode)
    with tb[7]:
        if ol_ok:
            with st.popover("Outlook 가져오기 ▾", use_container_width=True,
                            disabled=no_edit):
                st.caption("Outlook에 이미 있는 이 주 일정을 달력에 표시 "
                           "(등록 시 중복되지 않음)")
                if st.button("팀 코드 일정만 가져오기",
                             use_container_width=True):
                    _import_week(cur, scope_all=False)
                if st.button("전체 일정 가져오기", use_container_width=True):
                    _import_week(cur, scope_all=True)
        else:
            st.button("Outlook 가져오기", disabled=True,
                      use_container_width=True,
                      help=f"Outlook 미연결 ({ol_msg}) — 회사 PC에서 사용 가능")
    with tb[8]:
        if st.button("Outlook 등록", use_container_width=True,
                     disabled=no_edit or not ol_ok,
                     help="이 주 업무를 Outlook 캘린더에 기입합니다. "
                          "기존 자동등록분은 교체되어 중복이 생기지 않고, "
                          "가져온 원본 일정은 건드리지 않습니다."
                          + ("" if ol_ok else f" (미연결: {ol_msg})")):
            _register_week(cur, replace=True)
    with tb[9]:
        with st.popover("보고서 ▾", use_container_width=True,
                        disabled=eff == "stats"):
            st.caption("보고 있는 주 = 금주(ACTUAL), 다음 주 = 차주(PLAN)")
            if st.button("Excel 보고서 생성", type="primary",
                         use_container_width=True):
                try:
                    nxt = cur + timedelta(weeks=1)
                    this_ev = [e for e in _week(cur)
                               if e.get("included", True)]
                    next_ev = [e for e in _week(nxt)
                               if e.get("included", True)]
                    sheet = f"{cur:%y%m%d}_{nxt + timedelta(days=4):%y%m%d}"
                    xl = generate_report_bytes(
                        this_ev, next_ev,
                        user_name or "미입력", emp_id or "미입력", sheet)
                    team_name = team_cfg.get("team_name", "팀")
                    base = f"주간업무보고_{team_name}_{cur:%Y%m%d}"
                    ver = 1
                    while (OUTPUT_DIR / f"{base}_v{ver}.xlsx").exists():
                        ver += 1
                    fname = f"{base}_v{ver}.xlsx"
                    OUTPUT_DIR.mkdir(exist_ok=True)
                    (OUTPUT_DIR / fname).write_bytes(xl)
                    # 생성 즉시 Excel로 열기
                    try:
                        os.startfile(OUTPUT_DIR / fname)
                        st.toast(f"보고서가 Excel에서 열립니다: {fname}")
                    except Exception:
                        # 열기 실패 시 브라우저 다운로드로 대체
                        import base64
                        b64 = base64.b64encode(xl).decode()
                        try:
                            import streamlit.components.v1 as components
                            components.html(
                                "<script>"
                                "const a = document.createElement('a');"
                                "a.href = 'data:application/vnd.openxmlformats-"
                                "officedocument.spreadsheetml.sheet;base64,"
                                + b64 + "';"
                                f"a.download = {json.dumps(fname)};"
                                "document.body.appendChild(a); a.click();"
                                "</script>", height=0)
                            st.toast(f"보고서 다운로드 시작: {fname}")
                        except Exception:
                            st.download_button(
                                "보고서 다운로드", data=xl, file_name=fname,
                                mime="application/vnd.openxmlformats-"
                                     "officedocument.spreadsheetml.sheet",
                                use_container_width=True)
                except Exception as e:
                    st.error(f"Excel 생성 오류: {e}")
            st.divider()
            if st.button("전체 기록 백업 (zip)", use_container_width=True,
                         help="주차별 업무 기록과 설정을 output 폴더에 zip으로 백업"):
                try:
                    import zipfile
                    OUTPUT_DIR.mkdir(exist_ok=True)
                    bbase = f"주간업무기록백업_{date.today():%Y%m%d}"
                    bver = 1
                    while (OUTPUT_DIR / f"{bbase}_v{bver}.zip").exists():
                        bver += 1
                    bpath = OUTPUT_DIR / f"{bbase}_v{bver}.zip"
                    n_files = 0
                    with zipfile.ZipFile(bpath, "w",
                                         zipfile.ZIP_DEFLATED) as z:
                        for p in sorted(HIST_DIR.glob("*.json")):
                            z.write(p, f"history/{p.name}")
                            n_files += 1
                        if PREFS_PATH.exists():
                            z.write(PREFS_PATH, PREFS_PATH.name)
                    st.toast(f"백업 완료: {bpath.name} (주차 {n_files}건)")
                    try:
                        os.startfile(OUTPUT_DIR)
                    except Exception:
                        pass
                except Exception as e:
                    st.error(f"백업 오류: {e}")
    with tb[10]:
        if st.button("달력" if st.session_state.stats_on else "분석",
                     use_container_width=True,
                     help="기간별 업무 시간 분석 대시보드"):
            st.session_state.stats_on = not st.session_state.stats_on
            st.rerun()

    if st_calendar is None:
        st.warning("달력 뷰를 쓰려면 streamlit-calendar 설치가 필요합니다 — "
                   "install.bat을 다시 실행하세요.")
        return

    # ── 미니 월 달력 (왼쪽 상시) ────────────────────────────────────
    MINI_CSS = """
    .fc { font-family: 'Pretendard','맑은 고딕',sans-serif; font-size:.66rem; }
    .fc .fc-toolbar-title { font-size:.82rem; color:#22355F; font-weight:700; }
    .fc .fc-toolbar.fc-header-toolbar { margin-bottom:.3em; }
    .fc .fc-button { padding:0 5px; font-size:.72rem; background:#FFFFFF;
                     color:#22355F; border:1px solid #D9D9D9; box-shadow:none; }
    .fc .fc-button:hover { background:#EFF3FA; }
    .fc .fc-daygrid-day-number { padding:1px 3px; color:#4F4F4F; }
    .fc .fc-col-header-cell-cushion { color:#22355F; font-weight:700; }
    .fc .fc-day-today .fc-daygrid-day-number {
      background:#22355F; color:#FFFFFF; border-radius:50%;
      width:1.5em; height:1.5em; display:inline-block; text-align:center; }
    .fc .fc-daygrid-day-frame { min-height:1.7em !important; }
    .fc .fc-day-sat .fc-daygrid-day-number,
    .fc .fc-day-sun .fc-daygrid-day-number { color:#B0B0B0; }
    """

    def _mini_calendar():
        sel_bg = [{"start": cur.isoformat(),
                   "end": (cur + timedelta(days=5)).isoformat(),
                   "display": "background", "color": "#C8D4EA"}]
        mstate = st_calendar(
            events=sel_bg,
            options={"initialView": "dayGridMonth",
                     "initialDate": cur.isoformat(),
                     "firstDay": 1, "locale": "ko", "height": 252,
                     "headerToolbar": {"left": "prev", "center": "title",
                                       "right": "next"},
                     "fixedWeekCount": False,
                     "editable": False, "selectable": False},
            custom_css=MINI_CSS, callbacks=["dateClick"],
            key=f"mini_{team_id}_{cur.isoformat()}"
                f"_{st.session_state.cal_nonce}")
        if isinstance(mstate, dict) and mstate.get("callback") == "dateClick":
            st.session_state.cal_nonce += 1
            try:
                d = _parse_cal_dt(mstate["dateClick"]["date"]).date()
                if d.weekday() >= 5:
                    d = _monday_of(d)
                st.session_state.cur_day = d
                st.session_state.cur_mon = _monday_of(d)
                st.session_state.stats_on = False
                if (st.session_state.get("view_seg") or "주") == "월":
                    st.session_state.view_pending = "주"
                st.rerun()
            except (KeyError, ValueError):
                pass

    # ── 큰 달력 이벤트/옵션 빌더 ────────────────────────────────────
    def _cal_events_week(monday: date) -> list:
        ev = _week(monday)
        out = []
        for i, e in enumerate(ev):
            if not e.get("included", True):
                continue
            if e.get("is_holiday"):
                bg, fg, border = AMBER, "#FFFFFF", AMBER
            elif e.get("from_outlook"):
                bg, fg, border = "#FFFFFF", NAVY, NAVY
            elif e.get("code_type") == "KPI":
                bg, fg, border = NAVY, "#FFFFFF", NAVY
            elif e.get("code_type") == "Non-KPI":
                bg, fg, border = "#8B99B8", "#FFFFFF", "#8B99B8"
            else:
                bg, fg, border = "#999999", "#FFFFFF", "#999999"
            if e.get("recurring"):
                border = AMBER                 # 정기 일정 = 앰버 테두리
            code = e.get("code", "")
            out.append({
                "id": str(i),
                "title": (f"{code} {e.get('title', '')}"
                          if code and code != "미분류" else e.get("title", "")),
                "start": e["start"].strftime("%Y-%m-%dT%H:%M:%S"),
                "end":   e["end"].strftime("%Y-%m-%dT%H:%M:%S"),
                "backgroundColor": bg, "borderColor": border,
                "textColor": fg,
            })
        # 종일 줄: 요일마다 근무/휴무 칩 상시 표시 (클릭 = 전환)
        for wd in range(5):
            d = monday + timedelta(days=wd)
            if _day_is_hol(ev, d):
                ttl = f"휴무 · {hols[d]}" if d in hols else "휴무 (연차)"
                out.append({"id": f"day_{d.isoformat()}", "allDay": True,
                            "start": d.isoformat(), "title": ttl,
                            "backgroundColor": AMBER, "borderColor": AMBER,
                            "textColor": "#FFFFFF"})
            else:
                ttl = f"근무 · {hols[d]}" if d in hols else "근무"
                out.append({"id": f"day_{d.isoformat()}", "allDay": True,
                            "start": d.isoformat(), "title": ttl,
                            "backgroundColor": "#EDEDED",
                            "borderColor": "#CCCCCC", "textColor": "#4F4F4F"})
        # 점심 배경
        for wd in range(5):
            d = monday + timedelta(days=wd)
            out.append({"start": f"{d}T{t_ls:%H:%M}:00",
                        "end": f"{d}T{t_le:%H:%M}:00",
                        "display": "background", "color": "#E5E5E5"})
        return out

    def _cal_options_grid(view: str, anchor: date, days: int) -> dict:
        return {
            "initialView": view, "initialDate": anchor.isoformat(),
            "firstDay": 1, "weekends": False, "allDaySlot": True,
            "allDayText": "구분",
            "slotMinTime": "07:00:00", "slotMaxTime": "20:00:00",
            "slotDuration": "00:30:00", "snapDuration": "00:30:00",
            "editable": True, "selectable": True,
            "eventResizableFromStart": True,   # 위쪽 모서리로도 시간 조절
            # 겹침 허용: 늘리면 이웃 블록이 자동으로 줄어듦 (핸들러에서 정리)
            "eventOverlap": True, "selectOverlap": False,
            "locale": "ko", "height": 700,
            "headerToolbar": False,
            "validRange": {"start": anchor.isoformat(),
                           "end": (anchor + timedelta(days=days)).isoformat()},
            "businessHours": {"daysOfWeek": [1, 2, 3, 4, 5],
                              "startTime": t_ws.strftime("%H:%M"),
                              "endTime": t_we.strftime("%H:%M")},
            "eventTimeFormat": {"hour": "2-digit", "minute": "2-digit",
                                "hour12": False},
            "slotLabelFormat": {"hour": "2-digit", "minute": "2-digit",
                                "hour12": False},
        }

    def _cal_month() -> tuple[list, dict]:
        first = cur.replace(day=1)
        last = (first.replace(day=28) + timedelta(days=7)).replace(day=1)
        evs = []
        m = _monday_of(first)
        while m < last:
            wk = _week(m)
            for e in wk:
                if not e.get("included", True):
                    continue
                if e.get("is_holiday"):
                    bg = AMBER
                elif e.get("from_outlook"):
                    bg = "#FFFFFF"
                elif e.get("code_type") == "KPI":
                    bg = NAVY
                elif e.get("code_type") == "Non-KPI":
                    bg = "#8B99B8"
                else:
                    bg = "#999999"
                evs.append({
                    "id": f"m_{m.isoformat()}",
                    "title": f"{e.get('code','')} {e.get('title','')}"[:30],
                    "start": e["start"].strftime("%Y-%m-%dT%H:%M:%S"),
                    "end":   e["end"].strftime("%Y-%m-%dT%H:%M:%S"),
                    "backgroundColor": bg, "borderColor": bg,
                    "textColor": NAVY if bg == "#FFFFFF" else "#FFFFFF",
                })
            m += timedelta(weeks=1)
        opts = {
            "initialView": "dayGridMonth", "initialDate": first.isoformat(),
            "firstDay": 1, "weekends": True, "locale": "ko",
            "height": 700, "headerToolbar": False,
            "editable": False, "selectable": False,
            "dayMaxEventRows": True,
            "eventTimeFormat": {"hour": "2-digit", "minute": "2-digit",
                                "hour12": False},
        }
        return evs, opts

    # ── 분석 대시보드 ───────────────────────────────────────────────
    def _stats_page():
        import altair as alt
        st.radio("기간", ["최근 4주", "최근 12주", "올해", "전체"],
                 horizontal=True, key="stats_period",
                 label_visibility="collapsed")
        period = st.session_state.get("stats_period", "최근 12주")

        data: dict = {}
        for p in list_history(HIST_DIR, team_id):
            try:
                md = date.fromisoformat(p.stem[len(team_id) + 1:])
            except ValueError:
                continue
            ev = load_week(HIST_DIR, team_id, md)
            if ev:
                data[md] = ev
        for k, ev in st.session_state.weeks.items():   # 세션 최신본 우선
            if k.startswith(team_id + "_"):
                try:
                    data[date.fromisoformat(k[len(team_id) + 1:])] = ev
                except ValueError:
                    pass

        today = date.today()
        cutoff = {"최근 4주":  _monday_of(today) - timedelta(weeks=3),
                  "최근 12주": _monday_of(today) - timedelta(weeks=11),
                  "올해":      date(today.year, 1, 1),
                  "전체":      date(2000, 1, 1)}[period]
        rows = []
        for md, ev in sorted(data.items()):
            if md < cutoff:
                continue
            for e in ev:
                if not e.get("included", True):
                    continue
                c = by_code.get(e.get("code"), {})
                rows.append({
                    "주": f"{md:%m/%d}", "_m": md.isoformat(),
                    "유형": e.get("code_type", "미분류"),
                    "시간": float(e.get("duration_hours", 0)),
                    "분류": c.get("level1_name") or "미분류",
                    "업무": e.get("work_name") or e.get("title", ""),
                })
        if not rows:
            st.info("이 기간에는 기록이 없습니다. 달력에서 주를 채우면 "
                    "자동으로 분석에 반영됩니다.")
            return
        df = pd.DataFrame(rows)

        wk_n = df["_m"].nunique()
        tot = df["시간"].sum()
        cls = df[df["유형"].isin(["KPI", "Non-KPI"])]["시간"].sum()
        kpi = df[df["유형"] == "KPI"]["시간"].sum()
        meet = df[df["분류"].astype(str).str.contains("회의", na=False)]["시간"].sum()
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("기록된 주", f"{wk_n}주")
        m2.metric("총 M/H", f"{tot:.0f}h")
        m3.metric("주 평균", f"{tot / wk_n:.1f}h")
        m4.metric("KPI 비율", f"{(kpi / cls * 100) if cls else 0:.0f}%")
        m5.metric("회의 비중", f"{(meet / cls * 100) if cls else 0:.0f}%")

        type_scale = alt.Scale(domain=["KPI", "Non-KPI", "미분류"],
                               range=[NAVY, "#8B99B8", "#C9C9C9"])
        w = df.groupby(["_m", "주", "유형"], as_index=False)["시간"].sum()
        st.altair_chart(
            alt.Chart(w).mark_bar().encode(
                x=alt.X("주:N", sort=alt.SortField("_m"), title=None),
                y=alt.Y("시간:Q", title="M/H"),
                color=alt.Color("유형:N", scale=type_scale,
                                legend=alt.Legend(orient="top", title=None)),
                tooltip=["주", "유형", "시간"],
            ).properties(height=240, title="주별 업무 시간 추이"),
            use_container_width=True)

        cc1, cc2 = st.columns(2)
        cat = (df[df["유형"] != "미분류"]
               .groupby("분류", as_index=False)["시간"].sum()
               .sort_values("시간", ascending=False).head(8))
        if not cat.empty:
            cat["강조"] = cat["시간"] == cat["시간"].max()
            cc1.altair_chart(
                alt.Chart(cat).mark_bar().encode(
                    y=alt.Y("분류:N", sort="-x", title=None),
                    x=alt.X("시간:Q", title="M/H"),
                    color=alt.Color("강조:N",
                                    scale=alt.Scale(domain=[True, False],
                                                    range=[AMBER, NAVY]),
                                    legend=None),
                    tooltip=["분류", "시간"],
                ).properties(height=260, title="업무 분류별 시간 (Top 8)"),
                use_container_width=True)
        top = (df[df["유형"] != "미분류"]
               .groupby("업무", as_index=False)["시간"].sum()
               .sort_values("시간", ascending=False).head(10))
        if not top.empty:
            cc2.altair_chart(
                alt.Chart(top).mark_bar(color=NAVY60).encode(
                    y=alt.Y("업무:N", sort="-x", title=None),
                    x=alt.X("시간:Q", title="M/H"),
                    tooltip=["업무", "시간"],
                ).properties(height=260, title="자주 한 업무 (Top 10)"),
                use_container_width=True)
        st.caption("집계 기준: '포함' 상태의 일정 · 미분류는 유형 차트에만 표시")

    # ── 본문 레이아웃: 미니달력(좌) + 달력/분석(우) ─────────────────
    lc, rc = st.columns([0.2, 0.8], gap="medium")
    with lc:
        _mini_calendar()
        st.caption("날짜 클릭 = 해당 주로 이동")
        if eff in ("week", "day"):
            inc = [e for e in events if e.get("included", True)]
            if inc:
                r = validate(inc, target)
                diff = r["difference"]
                sym = "●" if abs(diff) <= 0.5 else ("▲" if diff > 0 else "▽")
                st.markdown(
                    f"<div style='color:{NAVY};font-weight:700;"
                    f"font-size:.85rem;padding-top:.4rem'>이번 주 "
                    f"{r['classified_hours']:.1f}h {sym} "
                    f"<span style='color:{NAVY60};font-weight:400'>"
                    f"/ 목표 {target:.0f}h</span></div>",
                    unsafe_allow_html=True)
                st.caption(f"KPI {r['kpi_hours']:.1f}h · "
                           f"Non-KPI {r['non_kpi_hours']:.1f}h")

    with rc:
        if eff == "stats":
            _stats_page()
        else:
            if eff in ("week", "day"):
                inc = [e for e in events if e.get("included", True)]
                if inc:
                    r = validate(inc, target)
                    if r["unclassified_count"]:
                        st.warning(
                            f"미분류 {r['unclassified_count']}건 "
                            f"({r['unclassified_hours']:.1f}h)은 집계·보고서에서 "
                            "제외됩니다 — 그레이 블록을 클릭해 코드를 지정하세요.")
                else:
                    st.caption("일정이 비어 있습니다 — 달력 빈 칸을 클릭해 직접 "
                               "입력하거나, [일정 자동 생성]으로 한 번에 채우세요. "
                               "요일 위 근무/휴무 칩 클릭 = 휴무 지정.")

            if month_mode:
                cal_events, cal_opts = _cal_month()
                cbs = ["dateClick", "eventClick"]
            elif eff == "day":
                cal_events = _cal_events_week(cur)
                cal_opts = _cal_options_grid("timeGridDay", day, 1)
                cbs = ["dateClick", "eventClick", "eventChange", "select"]
            else:
                cal_events = _cal_events_week(cur)
                cal_opts = _cal_options_grid("timeGridWeek", cur, 5)
                cbs = ["dateClick", "eventClick", "eventChange", "select"]

            state = st_calendar(
                events=cal_events, options=cal_opts, custom_css=CAL_CSS,
                callbacks=cbs,
                key=f"cal_{eff}_{team_id}_{cur.isoformat()}_{day.isoformat()}"
                    f"_{st.session_state.cal_nonce}",
            )

            if isinstance(state, dict) and state.get("callback"):
                cb = state["callback"]
                # 콜백 처리 즉시 리마운트(key 변경) — 팝업 취소 후 재클릭 보장
                st.session_state.cal_nonce += 1
                try:
                    if month_mode:
                        raw = (state.get("dateClick", {}).get("date")
                               or state.get("eventClick", {})
                                      .get("event", {}).get("start"))
                        if raw:
                            d0 = _parse_cal_dt(raw).date()
                            if d0.weekday() >= 5:
                                d0 = _monday_of(d0)
                            st.session_state.cur_day = d0
                            st.session_state.cur_mon = _monday_of(d0)
                            st.session_state.view_pending = "주"
                            st.rerun()
                    elif cb == "eventChange":
                        evd = state["eventChange"]["event"]
                        if not str(evd["id"]).startswith("day_"):
                            idx = int(evd["id"])
                            s = _parse_cal_dt(evd["start"])
                            en = (_parse_cal_dt(evd["end"]) if evd.get("end")
                                  else s + timedelta(
                                      hours=events[idx]["duration_hours"]))
                            e = dict(events[idx])
                            e.update(start=s, end=en, date=s.date(),
                                     duration_hours=round(
                                         (en - s).total_seconds() / 3600, 2))
                            _push_undo(cur)
                            events[idx] = e
                            # 겹친 이웃은 줄이거나 제거 — 늘리면 밀리는 동작
                            st.session_state.weeks[_wkey(cur)] = \
                                resolve_overlaps(events, idx)
                            _mutate(cur)
                    elif cb == "eventClick":
                        eid = str(state["eventClick"]["event"]["id"])
                        if eid.startswith("day_"):      # 근무/휴무 칩 클릭
                            _toggle_day(cur, date.fromisoformat(eid[4:]))
                        else:
                            _edit_dialog(cur, int(eid))
                    elif cb == "select":
                        s = _parse_cal_dt(state["select"]["start"])
                        en = _parse_cal_dt(state["select"]["end"])
                        if s.date() == en.date():
                            _add_dialog(cur, s.date(), s, en)
                    elif cb == "dateClick":
                        raw = str(state["dateClick"]["date"])
                        if "T" not in raw:              # 종일 칸 = 토글
                            _toggle_day(cur, date.fromisoformat(raw))
                        else:
                            s = _parse_cal_dt(raw)
                            _add_dialog(cur, s.date(), s,
                                        s + timedelta(hours=1))
                except (KeyError, ValueError, IndexError):
                    pass

            if not month_mode:
                st.caption(
                    "빈 칸 클릭/드래그 = 입력 · 블록 클릭 = 수정 · 드래그 = 이동 · "
                    "모서리 드래그 = 시간 조절(30분 단위) · "
                    "근무/휴무 칩 클릭 = 전환  |  "
                    "색: 네이비 KPI · 연네이비 Non-KPI · 앰버 휴무 · "
                    "앰버 테두리 정기일정 · 흰색 Outlook 원본 · 그레이 미분류  |  "
                    "수정 즉시 자동 저장")

                with st.expander("표로 일괄 편집 (포함/제외 · 제목 수정)"):
                    ev_now = _week(cur)
                    if ev_now:
                        df = _to_df(ev_now)
                        edited = st.data_editor(
                            df, use_container_width=True, hide_index=True,
                            key=f"editor_{cur.isoformat()}"
                                f"_{st.session_state.cal_nonce}",
                            column_config={
                                "포함": st.column_config.CheckboxColumn(
                                    "포함", width=50),
                                "M/H": st.column_config.NumberColumn(
                                    "M/H", width=52, format="%.1f"),
                                "업무": st.column_config.SelectboxColumn(
                                    "업무 (코드 변경 가능)", options=labels,
                                    width=430),
                                "제목": st.column_config.TextColumn(
                                    "제목", width=280),
                            },
                            disabled=["날짜", "요일", "시작", "종료",
                                      "M/H", "유형"])
                        new_ev = _apply_edits(ev_now, edited, by_label)
                        if new_ev != ev_now:
                            _push_undo(cur)
                            _set_week(cur, new_ev)


if __name__ == "__main__":
    main()
