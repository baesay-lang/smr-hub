@echo off
cd /d %~dp0
echo Checking for updates...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
echo =========================================
echo  Weekly Work Calendar starting...
echo  Browser will open automatically.
echo =========================================
python -m streamlit run autofill_app.py --browser.gatherUsageStats false
pause
