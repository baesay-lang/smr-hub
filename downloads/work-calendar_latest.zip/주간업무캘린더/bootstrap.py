# -*- coding: utf-8 -*-
"""
주간업무 캘린더 시작 런처
────────────────────────────────────────────────────────────────
자동 업데이트 확인 후 앱을 실행한다.
bat/ps1 스크립트 없이 Python만 사용 — 회사 보안정책(AppLocker)이
사용자 폴더의 스크립트 실행을 막아도 python.exe 경유라 동작함.
"""
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

BASE = "https://baesay-lang.github.io/smr-hub/downloads"
APP = os.path.dirname(os.path.abspath(__file__))

KEEP_DIRS = {"config", "output", "__pycache__"}   # 사용자 데이터·캐시 보존
SKIP_FILES = {"run.bat"}   # cmd가 읽는 중인 파일만 제외 (py는 교체 가능)


def ensure_deps():
    """필수 패키지 자가 복구 — 설치 중 pip이 실패했던 PC도 첫 실행에서 해결."""
    try:
        import streamlit  # noqa: F401
        import streamlit_calendar  # noqa: F401
        return
    except ImportError:
        pass
    print("필수 패키지가 없어 지금 설치합니다... (인터넷 필요, 1~5분)")
    req = os.path.join(APP, "requirements.txt")
    rc = subprocess.call([sys.executable, "-m", "pip", "install", "-r", req])
    if rc != 0:
        print()
        print("[오류] 패키지 설치에 실패했습니다.")
        print("사내 네트워크(프록시) 문제일 수 있습니다. 아래 명령을 직접 실행해 보세요:")
        print(f'  "{sys.executable}" -m pip install -r "{req}"')
        input("Enter 를 누르면 종료합니다...")
        sys.exit(1)


def _vt(v: str):
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except ValueError:
        return (0, 0, 0)


def check_update():
    try:
        with urllib.request.urlopen(f"{BASE}/work-calendar_version.json",
                                    timeout=5) as r:
            info = json.load(r)
    except Exception:
        return                            # 오프라인/차단 — 그냥 실행

    try:
        vfile = os.path.join(APP, "version.txt")
        local = "0.0.0"
        if os.path.exists(vfile):
            with open(vfile, encoding="ascii", errors="ignore") as f:
                local = f.read().strip()
        if _vt(info["version"]) <= _vt(local):
            return

        print(f"새 버전 v{info['version']} 발견 (현재 v{local}) — 업데이트 중...")
        tmp = tempfile.mkdtemp(prefix="wrcal_")
        zpath = os.path.join(tmp, "update.zip")
        urllib.request.urlretrieve(info["url"], zpath)
        ex = os.path.join(tmp, "x")
        with zipfile.ZipFile(zpath) as z:
            z.extractall(ex)
        entries = [os.path.join(ex, d) for d in os.listdir(ex)]
        src = (entries[0] if len(entries) == 1 and os.path.isdir(entries[0])
               else ex)

        # 앱 파일 교체 (사용자 데이터 폴더는 통째로 보존)
        # - 파일별 재시도: OneDrive 동기화·백신이 잠깐 잠근 파일 대응
        # - version.txt 는 전부 성공한 뒤 마지막에 기록 — 일부만 복사된
        #   상태로 버전이 올라가 재시도가 막히는 것을 방지
        def _copy_retry(s, d, tries=4):
            for _ in range(tries):
                try:
                    if os.path.exists(d):      # 읽기전용·잠금 해제 시도
                        try:
                            os.chmod(d, stat.S_IWRITE | stat.S_IREAD)
                        except OSError:
                            pass
                    shutil.copy2(s, d)
                    return True
                except OSError:
                    try:                       # 덮어쓰기 불가 → 삭제 후 재복사
                        os.remove(d)
                    except OSError:
                        pass
                    time.sleep(0.7)
            return False

        failed = []
        for root, dirs, files in os.walk(src):
            rel = os.path.relpath(root, src)
            if rel != "." and rel.split(os.sep)[0] in KEEP_DIRS:
                dirs[:] = []
                continue
            dst_dir = APP if rel == "." else os.path.join(APP, rel)
            os.makedirs(dst_dir, exist_ok=True)
            for f in files:
                if rel == "." and (f in SKIP_FILES or f == "version.txt"):
                    continue
                if not _copy_retry(os.path.join(root, f),
                                   os.path.join(dst_dir, f)):
                    failed.append(os.path.join(rel, f))

        # config 안에서 앱 콘텐츠성 파일만 갱신 (기록·개인설정은 보존)
        s_teams = os.path.join(src, "config", "teams")
        if os.path.isdir(s_teams):
            d_teams = os.path.join(APP, "config", "teams")
            os.makedirs(d_teams, exist_ok=True)
            for f in os.listdir(s_teams):
                shutil.copy2(os.path.join(s_teams, f), os.path.join(d_teams, f))
        s_hol = os.path.join(src, "config", "holidays_kr.json")
        if os.path.exists(s_hol):
            os.makedirs(os.path.join(APP, "config"), exist_ok=True)
            shutil.copy2(s_hol, os.path.join(APP, "config", "holidays_kr.json"))

        # 새 의존성 반영
        subprocess.call([sys.executable, "-m", "pip", "install", "-r",
                         os.path.join(APP, "requirements.txt"), "--quiet"])

        if failed:
            # 일부 실패 → version.txt 를 올리지 않아 다음 실행에서 재시도
            print(f"[주의] 일부 파일 교체 실패 ({len(failed)}건):")
            for f in failed:
                print(f"  - {f}")
            print("다음 실행 때 자동으로 다시 시도합니다. "
                  "(OneDrive 동기화 중이면 잠시 후 재실행)")
        else:
            # 낡은 바이트코드 캐시 제거 — 구버전 모듈이 남는 것 방지
            for r0, d0, _ in os.walk(APP):
                for dn in list(d0):
                    if dn == "__pycache__":
                        shutil.rmtree(os.path.join(r0, dn),
                                      ignore_errors=True)
                        d0.remove(dn)
            s_ver = os.path.join(src, "version.txt")
            if os.path.exists(s_ver):
                shutil.copy2(s_ver, os.path.join(APP, "version.txt"))
            print(f"업데이트 완료: v{info['version']}")
        shutil.rmtree(tmp, ignore_errors=True)
    except Exception as e:
        print(f"업데이트 건너뜀: {e}")


def main():
    print("=" * 45)
    print(" 주간업무 캘린더 시작 중...")
    print(" 잠시 후 브라우저가 자동으로 열립니다.")
    print(" (이 창을 닫으면 프로그램이 종료됩니다)")
    print("=" * 45)
    ensure_deps()
    check_update()
    os.chdir(APP)
    sys.exit(subprocess.call([
        sys.executable, "-m", "streamlit", "run",
        os.path.join(APP, "autofill_app.py"),
        "--browser.gatherUsageStats", "false",
    ]))


if __name__ == "__main__":
    main()
