# Weekly Work Calendar - auto updater (called by run.bat before launch)
# Checks SMR Hub for the latest version and updates in place.
# User data is preserved: config\history, user_prefs.json, holidays_extra.json, output
$BASE = "https://baesay-lang.github.io/smr-hub/downloads"
$APP  = $PSScriptRoot

try {
    $info = Invoke-RestMethod "$BASE/work-calendar_version.json" -TimeoutSec 5
} catch {
    exit 0    # offline or blocked -> just launch
}

try {
    $local = "0.0.0"
    if (Test-Path "$APP\version.txt") {
        $local = (Get-Content "$APP\version.txt" -TotalCount 1).Trim()
    }
    if ([version]$info.version -le [version]$local) { exit 0 }

    Write-Host "New version v$($info.version) found (current v$local) - updating..."
    $tmpZip = Join-Path $env:TEMP "work-calendar_update.zip"
    $tmpDir = Join-Path $env:TEMP "work-calendar_update"
    Invoke-WebRequest $info.url -OutFile $tmpZip -TimeoutSec 120
    if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }
    Expand-Archive $tmpZip -DestinationPath $tmpDir -Force
    $srcItem = Get-ChildItem $tmpDir -Directory | Select-Object -First 1
    $src = if ($srcItem) { $srcItem.FullName } else { $tmpDir }

    # App files (keep user data: config/, output/ excluded; updater files kept as-is)
    robocopy $src $APP /E /XD config output __pycache__ .streamlit /XF run.bat update.ps1 | Out-Null
    # App content inside config: team codes / holidays / theme (user history & prefs untouched)
    if (Test-Path "$src\config\teams") {
        robocopy "$src\config\teams" "$APP\config\teams" /E | Out-Null
    }
    if (Test-Path "$src\config\holidays_kr.json") {
        Copy-Item "$src\config\holidays_kr.json" "$APP\config\" -Force
    }
    if (Test-Path "$src\.streamlit\config.toml") {
        New-Item -ItemType Directory -Force "$APP\.streamlit" | Out-Null
        Copy-Item "$src\.streamlit\config.toml" "$APP\.streamlit\" -Force
    }
    # New dependencies, if any
    python -m pip install -r "$APP\requirements.txt" --quiet 2>$null

    Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
    Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Updated to v$($info.version)."
} catch {
    Write-Host "Update skipped: $($_.Exception.Message)"
}
exit 0
