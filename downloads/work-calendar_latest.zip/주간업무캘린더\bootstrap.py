# -*- coding: utf-8 -*-
"""
주간업무 캘린더 시작 런처
────────────────────────────────────────────────────────────────
자동 업데이트 확인 후 앱을 실행한다.
bat/ps1 스크립트 없이 Python만 사용 — 회사 보안정책(AppLocker)이
사용자 폴더의 스크립트 실행을 막아도 python.exe 경유라 동작함.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

BASE = "https://baesay-lang.github.io/smr-hub/downloads"
APP = os.path.dirname(os.path.abspath(__file__))

KEEP_DIRS = {"config", "output", "__pycache__"}   # 사용자 데이터·캐시 보존
SKIP_FILES = {"bootstrap.py", "run.bat", "update.ps1"}  # 실행 중 파일 제외


def _vt(v: str):
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except ValueError:
        return (0, 0, 0)


def check_update():
    try:
        with urllib.request.urlopen(f"{BASE}/work-calendar_version.json",
                                    timeout=5) as r:
            info = json.load(r)
    except Exception:
        return                            # 오프라인/차단 — 그냥 실행

    try:
        vfile = os.path.join(APP, "version.txt")
        local = "0.0.0"
        if os.path.exists(vfile):
            with open(vfile, encoding="ascii", errors="ignore") as f:
                local = f.read().strip()
        if _vt(info["version"]) <= _vt(local):
            return

        print(f"새 버전 v{info['version']} 발견 (현재 v{local}) — 업데이트 중...")
        tmp = tempfile.mkdtemp(prefix="wrcal_")
        zpath = os.path.join(tmp, "update.zip")
        urllib.request.urlretrieve(info["url"], zpath)
        ex = os.path.join(tmp, "x")
        with zipfile.ZipFile(zpath) as z:
            z.extractall(ex)
        entries = [os.path.join(ex, d) for d in os.listdir(ex)]
        src = (entries[0] if len(entries) == 1 and os.path.isdir(entries[0])
               else ex)

        # 앱 파일 교체 (사용자 데이터 폴더는 통째로 보존)
        for root, dirs, files in os.walk(src):
            rel = os.path.relpath(root, src)
            if rel != "." and rel.split(os.sep)[0] in KEEP_DIRS:
                dirs[:] = []
                continue
            dst_dir = APP if rel == "." else os.path.join(APP, rel)
            os.makedirs(dst_dir, exist_ok=True)
            for f in files:
                if rel == "." and f in SKIP_FILES:
                    continue
                shutil.copy2(os.path.join(root, f), os.path.join(dst_dir, f))

        # config 안에서 앱 콘텐츠성 파일만 갱신 (기록·개인설정은 보존)
        s_teams = os.path.join(src, "config", "teams")
        if os.path.isdir(s_teams):
            d_teams = os.path.join(APP, "config", "teams")
            os.makedirs(d_teams, exist_ok=True)
            for f in os.listdir(s_teams):
                shutil.copy2(os.path.join(s_teams, f), os.path.join(d_teams, f))
        s_hol = os.path.join(src, "config", "holidays_kr.json")
        if os.path.exists(s_hol):
            os.makedirs(os.path.join(APP, "config"), exist_ok=True)
            shutil.copy2(s_hol, os.path.join(APP, "config", "holidays_kr.json"))

        # 새 의존성 반영
        subprocess.call([sys.executable, "-m", "pip", "install", "-r",
                         os.path.join(APP, "requirements.txt"), "--quiet"])
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"업데이트 완료: v{info['version']}")
    except Exception as e:
        print(f"업데이트 건너뜀: {e}")


def main():
    print("=" * 45)
    print(" 주간업무 캘린더 시작 중...")
    print(" 잠시 후 브라우저가 자동으로 열립니다.")
    print(" (이 창을 닫으면 프로그램이 종료됩니다)")
    print("=" * 45)
    check_update()
    os.chdir(APP)
    sys.exit(subprocess.call([
        sys.executable, "-m", "streamlit", "run",
        os.path.join(APP, "autofill_app.py"),
        "--browser.gatherUsageStats", "false",
    ]))


if __name__ == "__main__":
    main()
