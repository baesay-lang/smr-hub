@echo off
cd /d %~dp0
echo Installing required packages (streamlit, streamlit-calendar,
echo pandas, openpyxl, pywin32, holidays)...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo Done. Run the app with run.bat
pause
