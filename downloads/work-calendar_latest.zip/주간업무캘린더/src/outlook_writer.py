# -*- coding: utf-8 -*-
"""
Outlook 캘린더 자동 기입 모듈 (데스크톱 Outlook, win32com)
────────────────────────────────────────────────────────────────
- 일정 제목: "{코드} [{KPI/Non-KPI}] {업무명}"
  → 기존 주간업무보고(WorkReport)의 CodeMatcher 가 그대로 인식하는 형식
- 자동 등록 일정에는 고유 카테고리를 붙여, 재등록 시 그 카테고리만
  안전하게 삭제·교체한다 (사용자가 직접 만든 일정은 건드리지 않음).
- Outlook 이 없는 PC를 위해 .ics 파일 생성 함수도 제공.
"""
from datetime import date, datetime, timedelta

CATEGORY = "주간업무자동"          # 자동 등록 표식 (Outlook 범주)
OL_APPOINTMENT = 1                # olAppointmentItem
OL_CALENDAR = 9                   # olFolderCalendar
OL_BUSY = 2                       # olBusy
OL_OOF = 3                        # olOutOfOffice


def subject_of(ev: dict) -> str:
    code = ev.get("code", "")
    ctype = ev.get("code_type", "")
    title = ev.get("title", ev.get("work_name", ""))
    if code and code != "미분류":
        return f"{code} [{ctype}] {title}"
    return title


def _com_init():
    """Streamlit 스크립트 스레드에서 COM 사용을 위한 초기화."""
    try:
        import pythoncom
        pythoncom.CoInitialize()
    except Exception:
        pass


# ── 기존 일정 불러오기 ────────────────────────────────────────────────
def read_week_events(monday: date) -> list[dict]:
    """해당 주 월~금의 Outlook 일정을 원시 형태로 읽는다.
    (기존 outlook_reader와 동일한 Sort→Restrict 패턴, en-US 날짜 필수)"""
    _com_init()
    import win32com.client
    app = win32com.client.Dispatch("Outlook.Application")
    cal = app.GetNamespace("MAPI").GetDefaultFolder(OL_CALENDAR)

    items = cal.Items
    items.IncludeRecurrences = True
    items.Sort("[Start]")
    start = datetime.combine(monday, datetime.min.time())
    end = start + timedelta(days=5)
    flt = (f"[Start] >= '{start.strftime('%m/%d/%Y 12:00 AM')}' AND "
           f"[Start] < '{end.strftime('%m/%d/%Y 12:00 AM')}'")
    rows = []
    for it in items.Restrict(flt):
        try:
            cats = [c.strip() for c in (it.Categories or "").split(",")]
            s, e = it.Start, it.End
            rows.append({
                "subject": str(it.Subject or "").strip(),
                "start": datetime(s.year, s.month, s.day, s.hour, s.minute),
                "end":   datetime(e.year, e.month, e.day, e.hour, e.minute),
                "allday": bool(it.AllDayEvent),
                "is_auto": CATEGORY in cats,
            })
        except Exception:
            continue
    return rows


def _find_code_in(title: str, codes: list[dict]) -> str | None:
    """제목에서 팀 코드 탐지 (기존 CodeMatcher와 동일한 경계 규칙)."""
    import re
    for code in sorted((c["code"] for c in codes), key=len, reverse=True):
        if re.search(r'(?<![0-9A-Za-z])' + re.escape(code) + r'(?![0-9A-Za-z])',
                     title):
            return code
    return None


def convert_outlook_rows(rows: list[dict], monday: date, codes: list[dict],
                         scope_all: bool) -> tuple[list[dict], int]:
    """원시 일정 → 앱 이벤트 목록.
    - 자동 등록분(범주)·종일 일정은 제외
    - scope_all=False 면 팀 코드가 매칭되는 일정만
    Returns (이벤트 목록, 자동등록 제외 건수)"""
    by_code = {c["code"]: c for c in codes}
    out, skipped_auto = [], 0
    for r in rows:
        if r.get("is_auto"):
            skipped_auto += 1
            continue
        if r.get("allday"):
            continue
        d = r["start"].date()
        if not (monday <= d <= monday + timedelta(days=4)):
            continue
        dur = round((r["end"] - r["start"]).total_seconds() / 3600, 2)
        if dur <= 0:
            continue
        code = _find_code_in(r["subject"], codes)
        if code is None and not scope_all:
            continue
        c = by_code.get(code)
        out.append({
            "date": d, "start": r["start"], "end": r["end"],
            "duration_hours": dur,
            "title": r["subject"],
            "work_name": c["name"] if c else r["subject"],
            "code": code or "미분류",
            "code_type": c.get("type", "미분류") if c else "미분류",
            "included": True,
            "from_outlook": True,      # 등록 시 제외 (원본이 이미 존재)
        })
    return out, skipped_auto


def _has_outlook_profile() -> bool:
    """Outlook 계정(프로필) 존재 여부 — 미설정 PC에서 시작 마법사에
    걸려 멈추는 것을 막기 위한 사전 확인."""
    try:
        import winreg
    except ImportError:
        return True                      # 확인 불가 시 시도는 해 본다
    for ver in ("16.0", "15.0", "14.0"):
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                rf"Software\Microsoft\Office\{ver}\Outlook\Profiles")
            if winreg.QueryInfoKey(key)[0] > 0:
                return True
        except OSError:
            continue
    return False


def outlook_available(timeout: float = 6.0) -> tuple[bool, str]:
    """데스크톱 Outlook COM 사용 가능 여부 (앱이 멈추지 않도록
    프로필 사전 확인 + 타임아웃 적용)."""
    try:
        import win32com.client  # noqa: F401
    except ImportError:
        return False, "pywin32 미설치 (pip install pywin32)"

    if not _has_outlook_profile():
        return False, "Outlook 계정(프로필) 미설정"

    import threading
    result: dict = {}

    def _probe():
        try:
            _com_init()
            import win32com.client
            app = win32com.client.Dispatch("Outlook.Application")
            result["ver"] = app.Version
        except Exception as e:
            result["err"] = str(e)

    t = threading.Thread(target=_probe, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        return False, "Outlook 응답 없음 (초기 설정 창 대기 중일 수 있음)"
    if "ver" in result:
        return True, f"Outlook {result['ver']}"
    return False, f"Outlook 실행 불가: {result.get('err', '알 수 없음')}"


def _week_range(monday: date) -> tuple[datetime, datetime]:
    """삭제 검색 범위. 과거 시간대 버그로 ±9h 밀려 등록된 일정까지
    쓸어내도록 일요일 00:00 ~ 토요일 24:00 로 하루씩 넓게 잡는다.
    (카테고리가 붙은 자동 등록 일정만 지우므로 안전)"""
    start = datetime.combine(monday, datetime.min.time()) - timedelta(days=1)
    end = start + timedelta(days=7)      # 일 00:00 ~ 일 00:00
    return start, end


def delete_auto_events(monday: date) -> int:
    """해당 주(월~금)에서 CATEGORY 가 붙은 자동 등록 일정만 삭제."""
    _com_init()
    import win32com.client
    app = win32com.client.Dispatch("Outlook.Application")
    cal = app.GetNamespace("MAPI").GetDefaultFolder(OL_CALENDAR)
    start, end = _week_range(monday)

    items = cal.Items
    items.IncludeRecurrences = False
    items.Sort("[Start]")
    # Outlook 날짜 필터는 en-US 형식 필수 (기존 outlook_reader와 동일)
    flt = (f"[Start] >= '{start.strftime('%m/%d/%Y 12:00 AM')}' AND "
           f"[Start] < '{end.strftime('%m/%d/%Y 12:00 AM')}'")
    targets = []
    for it in items.Restrict(flt):
        try:
            cats = (it.Categories or "")
            if CATEGORY in [c.strip() for c in cats.split(",")]:
                targets.append(it)
        except Exception:
            continue
    n = 0
    for it in reversed(targets):
        try:
            it.Delete()
            n += 1
        except Exception:
            continue
    return n


def _fmt(dt: datetime) -> str:
    """시간대 개념이 없는 문자열(한국 wall-clock 그대로) — COM이
    datetime 객체를 UTC로 변환해 9시간 밀리는 문제를 원천 차단."""
    return dt.strftime("%Y-%m-%d %H:%M")


def _wall(com_dt) -> datetime:
    """COM에서 읽은 시간의 벽시계 값(시간대 정보 제거)."""
    return datetime(com_dt.year, com_dt.month, com_dt.day,
                    com_dt.hour, com_dt.minute)


def _set_times_verified(appt, start: datetime, end: datetime) -> None:
    """시작/종료를 넣고 저장 → Outlook에 실제 저장된 시간을 다시 읽어
    의도한 시간과 다르면 그 차이만큼 되밀어 자가 교정한다.
    (PC별 COM 시간대 동작 차이와 무관하게 항상 한국 시간 그대로 기록)"""
    start = start.replace(tzinfo=None, second=0, microsecond=0)
    end = end.replace(tzinfo=None, second=0, microsecond=0)
    try:
        appt.Start = _fmt(start)
        appt.End = _fmt(end)
    except Exception:                      # 문자열 거부 환경 → 객체로
        appt.Start = start
        appt.End = end
    appt.Save()

    for _ in range(2):                     # 검증 → 보정 → 재검증
        try:
            delta = start - _wall(appt.Start)
        except Exception:
            return
        if abs(delta.total_seconds()) < 60:
            return
        try:
            appt.Start = _fmt(start + delta)
            appt.End = _fmt(end + delta)
            appt.Save()
        except Exception:
            return


def register_events(events: list[dict], monday: date,
                    replace: bool = True) -> tuple[int, int]:
    """
    이벤트를 Outlook 기본 캘린더에 등록.
    replace=True 면 같은 주의 기존 자동 등록 일정을 먼저 삭제.
    Returns (등록 건수, 삭제 건수)
    """
    _com_init()
    import win32com.client
    deleted = delete_auto_events(monday) if replace else 0

    app = win32com.client.Dispatch("Outlook.Application")
    n = 0
    fullday_done: set = set()             # 종일 휴무 등록한 날짜
    for ev in events:
        if not ev.get("included", True):
            continue

        # 종일 휴무: 하루 1건 All-day + 부재중 (오전/오후 2블록 → 1건 통합)
        if ev.get("is_holiday") and ev.get("holiday_part", "full") == "full":
            if ev["date"] in fullday_done:
                continue
            appt = app.CreateItem(OL_APPOINTMENT)
            appt.Subject = subject_of(ev)
            appt.Categories = CATEGORY
            appt.BusyStatus = OL_OOF
            appt.ReminderSet = False
            appt.Body = "주간업무 자동작성 등록 (휴무)"
            appt.AllDayEvent = True
            appt.Start = ev["date"].strftime("%Y-%m-%d")
            appt.End = (ev["date"] + timedelta(days=1)).strftime("%Y-%m-%d")
            appt.Save()
            fullday_done.add(ev["date"])
            n += 1
            continue

        appt = app.CreateItem(OL_APPOINTMENT)
        appt.Subject = subject_of(ev)
        appt.Categories = CATEGORY
        appt.BusyStatus = OL_OOF if ev.get("is_holiday") else OL_BUSY
        appt.ReminderSet = False
        appt.Body = f"주간업무 자동작성 등록 ({ev.get('code_type','')} / {ev.get('code','')})"
        _set_times_verified(appt, ev["start"], ev["end"])
        n += 1
    return n, deleted


def register_one(ev: dict) -> int:
    """단일 이벤트를 Outlook에 등록.
    같은 날(±1일, 시간대 밀림 잔재 포함) 같은 제목의 자동 등록분은
    먼저 삭제해 교체한다 — 시간을 고쳐 다시 보내도 중복이 없음.
    Returns 삭제(교체)된 기존 건수."""
    _com_init()
    import win32com.client
    app = win32com.client.Dispatch("Outlook.Application")
    cal = app.GetNamespace("MAPI").GetDefaultFolder(OL_CALENDAR)

    subject = subject_of(ev)
    start = datetime.combine(ev["date"], datetime.min.time()) - timedelta(days=1)
    end = start + timedelta(days=3)
    items = cal.Items
    items.IncludeRecurrences = False
    items.Sort("[Start]")
    flt = (f"[Start] >= '{start.strftime('%m/%d/%Y 12:00 AM')}' AND "
           f"[Start] < '{end.strftime('%m/%d/%Y 12:00 AM')}'")
    targets = []
    for it in items.Restrict(flt):
        try:
            cats = [c.strip() for c in (it.Categories or "").split(",")]
            if CATEGORY in cats and str(it.Subject or "").strip() == subject:
                targets.append(it)
        except Exception:
            continue
    deleted = 0
    for it in reversed(targets):
        try:
            it.Delete()
            deleted += 1
        except Exception:
            continue

    appt = app.CreateItem(OL_APPOINTMENT)
    appt.Subject = subject
    appt.Categories = CATEGORY
    appt.BusyStatus = OL_OOF if ev.get("is_holiday") else OL_BUSY
    appt.ReminderSet = False
    appt.Body = (f"주간업무 자동작성 등록 "
                 f"({ev.get('code_type','')} / {ev.get('code','')})")
    _set_times_verified(appt, ev["start"], ev["end"])
    return deleted


# ── ICS (Outlook COM 이 없을 때 가져오기용) ──────────────────────────
def build_ics(events: list[dict]) -> str:
    def esc(s: str) -> str:
        return (s.replace("\\", "\\\\").replace(";", r"\;")
                 .replace(",", r"\,").replace("\n", r"\n"))

    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//WorkReport AutoFill//KR",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
    ]
    for i, ev in enumerate(events):
        if not ev.get("included", True):
            continue
        uid = f"wra-{ev['start']:%Y%m%dT%H%M}-{i}@autofill"
        lines += [
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{ev['start']:%Y%m%dT%H%M%S}",
            f"DTSTART:{ev['start']:%Y%m%dT%H%M%S}",
            f"DTEND:{ev['end']:%Y%m%dT%H%M%S}",
            f"SUMMARY:{esc(subject_of(ev))}",
            f"CATEGORIES:{CATEGORY}",
            "END:VEVENT",
        ]
    lines.append("END:VCALENDAR")
    return "\r\n".join(lines) + "\r\n"
