# -*- coding: utf-8 -*-
"""
주간업무 자동작성 — exe 진입점 (PyInstaller 전용)
exe 옆의 autofill_app.py 를 streamlit으로 구동한다.
(app/src/config 는 exe 밖에 두어 팀 코드 수정·이력 저장이 그대로 가능)
"""
import os
import sys
import multiprocessing


def _base_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _skip_streamlit_onboarding():
    """첫 실행 시 이메일 입력 프롬프트가 뜨지 않게 credentials.toml 생성."""
    os.environ.setdefault("STREAMLIT_BROWSER_GATHER_USAGE_STATS", "false")
    d = os.path.join(os.path.expanduser("~"), ".streamlit")
    p = os.path.join(d, "credentials.toml")
    try:
        if not os.path.exists(p):
            os.makedirs(d, exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write('[general]\nemail = ""\n')
    except Exception:
        pass


def main():
    base = _base_dir()

    internal = os.path.join(base, "_internal")
    if getattr(sys, "frozen", False) and not os.path.isdir(internal):
        print("[오류] _internal 폴더가 없습니다.")
        print("exe 파일만 복사하면 실행되지 않습니다.")
        print("WorkReport_AutoFill 폴더 전체를 복사한 뒤 그 안에서 실행하세요.")
        input("Enter 를 누르면 종료합니다...")
        sys.exit(1)

    app = os.path.join(base, "autofill_app.py")
    if not os.path.exists(app):
        print(f"[오류] autofill_app.py 를 찾을 수 없습니다: {app}")
        print("exe와 같은 폴더에 autofill_app.py / src / config 가 있어야 합니다.")
        print("폴더 전체를 복사했는지 확인하세요.")
        input("Enter 를 누르면 종료합니다...")
        sys.exit(1)

    os.chdir(base)
    _skip_streamlit_onboarding()

    from streamlit.web import cli as stcli
    sys.argv = [
        "streamlit", "run", app,
        "--global.developmentMode=false",
        "--browser.gatherUsageStats=false",
        "--server.fileWatcherType=none",
        "--server.port=8531",
    ]
    print("=" * 45)
    print(" 주간업무 자동작성 v1.0 시작 중...")
    print(" 잠시 후 브라우저가 자동으로 열립니다.")
    print(" 안 열리면 주소창에 http://localhost:8531 입력")
    print(" (이 창을 닫으면 프로그램이 종료됩니다)")
    print("=" * 45)
    sys.exit(stcli.main())


if __name__ == "__main__":
    multiprocessing.freeze_support()
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        import traceback
        print()
        print("[오류] 실행 중 문제가 발생했습니다:")
        traceback.print_exc()
        print()
        input("위 오류 내용을 확인한 뒤 Enter 를 누르면 종료합니다...")
        sys.exit(1)
